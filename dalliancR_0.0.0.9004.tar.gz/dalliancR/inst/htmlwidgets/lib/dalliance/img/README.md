Spinners from:

        https://github.com/sjhcockrell/spinners
